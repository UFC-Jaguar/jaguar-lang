#!/bin/bash
python3 -m venv venv
source venv/bin/activate
pip install threadpoolctl
pip install numpy
deactivate
